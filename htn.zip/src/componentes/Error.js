import React, { Component } from 'react';

class Error extends Component {

    render() {
        return (
            <h1>Ruta No Encontrada</h1>
        );
    }
}

export default Error;
